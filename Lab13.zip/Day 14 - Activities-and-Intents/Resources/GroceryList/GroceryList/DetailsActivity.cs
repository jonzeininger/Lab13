﻿using Android.App;
using Android.OS;
using Android.Widget;

namespace GroceryList
{
	[Activity(Label = "Details")]			
	public class DetailsActivity : Activity
	{
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);
			SetContentView(Resource.Layout.Details);

            // int position = 0;

            int position = Intent.GentIntExtra("ItemPosition", -1);

			// TODO

			var item = MainActivity.Items[position];

            txtName = FindViewID<TextView>(Resource.ID.nameTextView);
            txtCount = FindViewID<TextView>(Resource.ID.countTextView);

            txtName.Text = "Name: " + item.Name;
            txtCount.Text = "Count: " + item.Count.ToString();
		}
	}
}